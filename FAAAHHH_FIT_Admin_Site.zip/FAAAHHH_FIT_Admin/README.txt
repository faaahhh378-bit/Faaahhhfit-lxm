FAAAHHH FIT ADMIN DASHBOARD

Open admin.html in the same browser/device used to collect the website submissions.

Features:
- Pending reviews
- Approve reviews
- Approved reviews
- Subscription waitlist
- Export data to JSON
- Clear local demo data

IMPORTANT: this current website stores data in browser localStorage. It is NOT a cloud admin system. For a live QR campaign where customers use their own phones, connect the website and admin dashboard to Supabase/Firebase.
